/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!************************************************!*\
  !*** ./resources/js/pages/form-wizard.init.js ***!
  \************************************************/
$(function () {
  $("#basic-example").steps({
    headerTag: "h3",
    bodyTag: "section",
    transitionEffect: "slide"
  }), $("#vertical-example").steps({
    headerTag: "h3",
    bodyTag: "section",
    transitionEffect: "slide",
    stepsOrientation: "vertical"
  });
});
/******/ })()
;