/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!******************************************************!*\
  !*** ./resources/js/pages/ecommerce-select2.init.js ***!
  \******************************************************/
$(".select2").select2();
/******/ })()
;