/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!************************************************!*\
  !*** ./resources/js/pages/task-kanban.init.js ***!
  \************************************************/
dragula([document.getElementById("upcoming-task"), document.getElementById("inprogress-task"), document.getElementById("complete-task")]);
/******/ })()
;