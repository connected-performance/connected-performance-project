INSERT INTO
  `form_builders` (
    `id`,
    `created_by`,
    `name`,
    `code`,
    `is_active`,
    `is_lead_active`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    2,
    1,
    'Inquire About Our Services',
    'vnt6i9o2wqz10syhm8r3',
    '1',
    '1',
    '2022-09-30 09:52:33',
    '2022-09-30 09:52:33'
  );