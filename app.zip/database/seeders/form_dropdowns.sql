INSERT INTO
  `form_dropdowns` (
    `id`,
    `form_field_id`,
    `key`,
    `value`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    7,
    6,
    '1_on_1_training',
    '1 on 1 training',
    '2022-09-30 09:58:00',
    '2022-09-30 09:58:00'
  ),
  (
    8,
    6,
    'consulting',
    'Consulting',
    '2022-09-30 09:58:00',
    '2022-09-30 09:58:00'
  ),
  (
    9,
    6,
    'connect_sofware',
    'Connect Sofware',
    '2022-09-30 09:58:00',
    '2022-09-30 09:58:00'
  ),
  (
    10,
    7,
    '1_on_1_training',
    '1 on 1 training',
    '2022-09-30 09:59:04',
    '2022-09-30 09:59:04'
  );